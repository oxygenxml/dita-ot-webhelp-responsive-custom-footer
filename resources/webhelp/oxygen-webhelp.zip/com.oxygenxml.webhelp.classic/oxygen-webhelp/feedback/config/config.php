<?php
/*
    
Oxygen WebHelp Plugin
Copyright (c) 1998-2017 Syncro Soft SRL, Romania.  All rights reserved.

*/


define("__PRODUCT_NAME__" , '@PRODUCT_ID@');
define("__PRODUCT_VERSION__" , '@PRODUCT_VERSION@');