/*

 Oxygen WebHelp Plugin
 Copyright (c) 1998-2017 Syncro Soft SRL, Romania.  All rights reserved.

 */
/**
 * @description Product Name
 * @type {string}
 */
var productName = '@PRODUCT_ID@';

/**
 * @description Product Version
 * @type {string}
 */
var productVersion = '@PRODUCT_VERSION@';

var conf = {};