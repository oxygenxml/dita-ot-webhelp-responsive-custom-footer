// Expanded from webhelp.search.ranking ANT property
var webhelpSearchRanking = @@SEARCH_RANKING@@;

// Expanded from webhelp.enable.search.autocomplete ANT property
var webhelpEnableSearchAutocomplete = @@ENABLE_AUTOCOMPLETE@@;

// Expanded from webhelp.search.enable.pagination ANT property
var webhelpEnableSearchPagination = @@ENABLE_SEARCH_PAGINATION@@;

// Expanded from webhelp.search.page.numberOfItems ANT property
var webhelpSearchNumberOfItems = @@SEARCH_NUMBER_OF_ITEMS@@;
